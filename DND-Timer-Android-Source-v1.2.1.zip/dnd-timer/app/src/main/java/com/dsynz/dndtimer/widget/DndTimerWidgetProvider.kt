package com.dsynz.dndtimer.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import com.dsynz.dndtimer.MainActivity
import com.dsynz.dndtimer.R
import com.dsynz.dndtimer.settings.AppPreferences
import com.dsynz.dndtimer.timer.StartResult
import com.dsynz.dndtimer.timer.TimerManager
import com.dsynz.dndtimer.timer.TimerRepository
import java.text.DateFormat
import java.util.Date

class DndTimerWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateWidget(context, manager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle,
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        updateWidget(context, appWidgetManager, appWidgetId)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val manager = TimerManager(context.applicationContext)
        when (intent.action) {
            ACTION_START_PRESET -> {
                val minutes = intent.getIntExtra(EXTRA_MINUTES, 0)
                val repository = TimerRepository(context)
                val result = manager.start(
                    minutes,
                    repository.defaultAllowVibration(),
                    repository.defaultAllowAlarms(),
                )
                if (result != StartResult.Started) openApp(context)
            }
            ACTION_EXTEND_15 -> manager.extend(15)
            ACTION_EXTEND_30 -> manager.extend(30)
        }
        requestUpdate(context)
    }

    private fun updateWidget(context: Context, manager: AppWidgetManager, appWidgetId: Int) {
        val minWidth = manager.getAppWidgetOptions(appWidgetId)
            .getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, COMPACT_WIDTH_DP)
        val layout = if (minWidth >= WIDE_WIDTH_DP) {
            R.layout.widget_dnd_timer_wide
        } else {
            R.layout.widget_dnd_timer
        }
        manager.updateAppWidget(appWidgetId, buildViews(context, layout))
    }

    private fun buildViews(context: Context, layout: Int): RemoteViews {
        val views = RemoteViews(context.packageName, layout)
        val state = TimerRepository(context).state()
        val presets = AppPreferences(context).presets().take(4)

        views.setOnClickPendingIntent(R.id.widget_header, openAppIntent(context, 8100))
        views.setOnClickPendingIntent(
            R.id.widget_settings,
            openAppIntent(context, 8101, MainActivity.EXTRA_OPEN_SETTINGS),
        )
        views.setOnClickPendingIntent(R.id.widget_custom, openAppIntent(context, 8102))

        if (state.isActive) {
            views.setViewVisibility(R.id.widget_idle_content, View.GONE)
            views.setViewVisibility(R.id.widget_active_content, View.VISIBLE)
            views.setTextViewText(R.id.widget_status, "ACTIVE")
            views.setTextColor(R.id.widget_status, context.getColor(R.color.widget_accent))
            val base = SystemClock.elapsedRealtime() +
                (state.endAtMillis - System.currentTimeMillis()).coerceAtLeast(0L)
            views.setChronometer(R.id.widget_chronometer, base, null, true)
            val until = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(state.endAtMillis))
            views.setTextViewText(R.id.widget_until, "Until $until")
            views.setOnClickPendingIntent(R.id.widget_extend_15, broadcastIntent(context, ACTION_EXTEND_15, 8215))
            views.setOnClickPendingIntent(R.id.widget_extend_30, broadcastIntent(context, ACTION_EXTEND_30, 8230))
            views.setOnClickPendingIntent(
                R.id.widget_end,
                openAppIntent(context, 8200, MainActivity.EXTRA_CONFIRM_END),
            )
        } else {
            views.setViewVisibility(R.id.widget_idle_content, View.VISIBLE)
            views.setViewVisibility(R.id.widget_active_content, View.GONE)
            views.setTextViewText(R.id.widget_status, "Ready")
            views.setTextColor(R.id.widget_status, context.getColor(R.color.widget_text_secondary))
            val ids = listOf(R.id.widget_preset_1, R.id.widget_preset_2, R.id.widget_preset_3, R.id.widget_preset_4)
            ids.forEachIndexed { index, id ->
                val value = presets.getOrElse(index) { AppPreferences.DEFAULT_PRESETS[index] }
                views.setTextViewText(id, formatDuration(value))
                views.setOnClickPendingIntent(
                    id,
                    broadcastIntent(context, ACTION_START_PRESET, 8300 + index, value),
                )
            }
        }
        return views
    }

    private fun openApp(context: Context) {
        context.startActivity(
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
        )
    }

    private fun openAppIntent(context: Context, requestCode: Int, booleanExtra: String? = null): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            booleanExtra?.let { putExtra(it, true) }
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun broadcastIntent(
        context: Context,
        action: String,
        requestCode: Int,
        minutes: Int = 0,
    ): PendingIntent {
        val intent = Intent(context, DndTimerWidgetProvider::class.java).apply {
            this.action = action
            if (minutes > 0) putExtra(EXTRA_MINUTES, minutes)
        }
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    companion object {
        private const val ACTION_START_PRESET = "com.dsynz.dndtimer.widget.START_PRESET"
        private const val ACTION_EXTEND_15 = "com.dsynz.dndtimer.widget.EXTEND_15"
        private const val ACTION_EXTEND_30 = "com.dsynz.dndtimer.widget.EXTEND_30"
        private const val EXTRA_MINUTES = "minutes"
        private const val COMPACT_WIDTH_DP = 180
        private const val WIDE_WIDTH_DP = 240

        fun requestUpdate(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, DndTimerWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isNotEmpty()) {
                val intent = Intent(context, DndTimerWidgetProvider::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                context.sendBroadcast(intent)
            }
        }

        private fun formatDuration(minutes: Int): String = when {
            minutes < 60 -> "$minutes min"
            minutes % 60 == 0 -> if (minutes == 60) "1 hour" else "${minutes / 60} hours"
            else -> "${minutes / 60}h ${minutes % 60}m"
        }
    }
}
