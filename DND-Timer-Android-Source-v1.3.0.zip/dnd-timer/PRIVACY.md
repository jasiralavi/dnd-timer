# Privacy Policy — DND Timer

**Effective date:** September 20, 2026  
**Developer:** DSYNZ

DND Timer does not collect, transmit, sell, or share personal information.

## Data handling

- Timer state, appearance preferences, and custom presets are stored only on the user's device.
- The app does not include analytics, advertising, tracking, crash-reporting, or social-media SDKs.
- The app does not request Internet access and does not send data to DSYNZ or any third party.

## Android permissions

DND Timer requests only the permissions needed for its user-facing features:

- **Do Not Disturb access:** Activates DND and restores the previous sound settings.
- **Alarms & reminders:** Ends a timer at the selected time, including while the device is idle.
- **Notifications:** Displays the active timer and its controls.
- **Run at startup:** Restores an active timer after a device restart.
- **Audio settings:** Applies and restores the selected vibration and alarm behaviour.

Permissions can be revoked at any time in Android Settings. Some features may stop working when their required permission is disabled.

## Backups

Android may back up the app's local preferences when the device's system backup feature is enabled. DSYNZ does not receive or control those backups.

## Changes

Material changes to this policy will be published with the application source and reflected by a new effective date.

## Contact

For privacy questions, contact **work@dsynz.com** or visit **https://dsynz.com**.
