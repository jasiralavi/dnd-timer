package com.dsynz.dndtimer.timer

data class TimerState(
    val isActive: Boolean,
    val startedAtMillis: Long,
    val endAtMillis: Long,
    val allowVibration: Boolean,
    val allowAlarms: Boolean,
    val muteMedia: Boolean,
)

enum class StartResult {
    Started,
    MissingDndAccess,
    Failed,
}
