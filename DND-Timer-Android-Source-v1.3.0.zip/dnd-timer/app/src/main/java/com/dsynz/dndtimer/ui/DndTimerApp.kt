package com.dsynz.dndtimer.ui

import android.app.TimePickerDialog
import android.text.format.DateFormat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dsynz.dndtimer.settings.AppPreferences
import com.dsynz.dndtimer.settings.ThemeMode
import com.dsynz.dndtimer.settings.TimeFormatMode
import com.dsynz.dndtimer.schedule.DndSchedule
import com.dsynz.dndtimer.schedule.ScheduleDays
import com.dsynz.dndtimer.timer.TimerState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import java.util.Date
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Calendar

@Composable
fun DndTimerApp(
    state: TimerState,
    hasDndAccess: Boolean,
    hasExactAlarmAccess: Boolean,
    presets: List<Int>,
    themeMode: ThemeMode,
    timeFormatMode: TimeFormatMode,
    schedules: List<DndSchedule>,
    endConfirmationRequest: Int,
    settingsRequest: Int,
    onGrantDndAccess: () -> Unit,
    onGrantExactAlarmAccess: () -> Unit,
    onStart: (minutes: Int, allowVibration: Boolean, allowAlarms: Boolean, muteMedia: Boolean) -> Unit,
    onExtend: (minutes: Int) -> Unit,
    onEnd: () -> Unit,
    onSaveDefaults: (allowVibration: Boolean, allowAlarms: Boolean, muteMedia: Boolean) -> Unit,
    onSavePresets: (List<Int>) -> Unit,
    onThemeModeChange: (ThemeMode) -> Unit,
    onTimeFormatModeChange: (TimeFormatMode) -> Unit,
    onSaveSchedule: (DndSchedule) -> Unit,
    onDeleteSchedule: (Long) -> Unit,
    onSetScheduleEnabled: (Long, Boolean) -> Unit,
    onOpenAppSettings: () -> Unit,
    onOpenBatterySettings: () -> Unit,
) {
    var showSettings by remember { mutableStateOf(false) }
    var showSchedules by remember { mutableStateOf(false) }
    var editingSchedule by remember { mutableStateOf<DndSchedule?>(null) }
    var addingSchedule by remember { mutableStateOf(false) }
    var confirmEnd by remember { mutableStateOf(false) }

    LaunchedEffect(endConfirmationRequest) {
        if (endConfirmationRequest > 0 && state.isActive) confirmEnd = true
    }
    LaunchedEffect(settingsRequest) {
        if (settingsRequest > 0) showSettings = true
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
    ) { innerPadding ->
        when {
            addingSchedule || editingSchedule != null -> ScheduleEditorScreen(
                schedule = editingSchedule,
                timeFormatMode = timeFormatMode,
                onBack = { addingSchedule = false; editingSchedule = null },
                onSave = {
                    onSaveSchedule(it)
                    addingSchedule = false
                    editingSchedule = null
                },
                onDelete = editingSchedule?.let { schedule ->
                    {
                        onDeleteSchedule(schedule.id)
                        editingSchedule = null
                    }
                },
                modifier = Modifier.padding(innerPadding),
            )
            showSchedules -> ScheduleListScreen(
                schedules = schedules,
                timeFormatMode = timeFormatMode,
                onBack = { showSchedules = false },
                onAdd = { addingSchedule = true },
                onEdit = { editingSchedule = it },
                onSetEnabled = onSetScheduleEnabled,
                modifier = Modifier.padding(innerPadding),
            )
            showSettings -> SettingsScreen(
                defaults = Triple(state.allowVibration, state.allowAlarms, state.muteMedia),
                presets = presets,
                themeMode = themeMode,
                timeFormatMode = timeFormatMode,
                onBack = { showSettings = false },
                onSaveDefaults = onSaveDefaults,
                onSavePresets = onSavePresets,
                onThemeModeChange = onThemeModeChange,
                onTimeFormatModeChange = onTimeFormatModeChange,
                onOpenAppSettings = onOpenAppSettings,
                onOpenBatterySettings = onOpenBatterySettings,
                modifier = Modifier.padding(innerPadding),
            )
            state.isActive -> ActiveTimerScreen(
                state = state,
                onSettings = { showSettings = true },
                onExtend = onExtend,
                onEndRequested = { confirmEnd = true },
                timeFormatMode = timeFormatMode,
                onTimerExpired = onEnd,
                modifier = Modifier.padding(innerPadding),
            )
            else -> TimerSetupScreen(
                hasDndAccess = hasDndAccess,
                hasExactAlarmAccess = hasExactAlarmAccess,
                presets = presets,
                defaultAllowVibration = state.allowVibration,
                defaultAllowAlarms = state.allowAlarms,
                defaultMuteMedia = state.muteMedia,
                onSettings = { showSettings = true },
                onSchedules = { showSchedules = true },
                enabledScheduleCount = schedules.count { it.enabled },
                timeFormatMode = timeFormatMode,
                onGrantDndAccess = onGrantDndAccess,
                onGrantExactAlarmAccess = onGrantExactAlarmAccess,
                onStart = onStart,
                modifier = Modifier.padding(innerPadding),
            )
        }
    }

    if (confirmEnd) {
        AlertDialog(
            onDismissRequest = { confirmEnd = false },
            title = { Text("End Do Not Disturb?") },
            text = { Text("Sound and notifications will return immediately.") },
            dismissButton = { TextButton(onClick = { confirmEnd = false }) { Text("Cancel") } },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmEnd = false
                        onEnd()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                ) { Text("End DND") }
            },
        )
    }
}

@Composable
private fun TimerSetupScreen(
    hasDndAccess: Boolean,
    hasExactAlarmAccess: Boolean,
    presets: List<Int>,
    defaultAllowVibration: Boolean,
    defaultAllowAlarms: Boolean,
    defaultMuteMedia: Boolean,
    onSettings: () -> Unit,
    onSchedules: () -> Unit,
    enabledScheduleCount: Int,
    timeFormatMode: TimeFormatMode,
    onGrantDndAccess: () -> Unit,
    onGrantExactAlarmAccess: () -> Unit,
    onStart: (Int, Boolean, Boolean, Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    var hours by remember { mutableIntStateOf(1) }
    var minutes by remember { mutableIntStateOf(0) }
    var allowVibration by remember(defaultAllowVibration) { mutableStateOf(defaultAllowVibration) }
    var allowAlarms by remember(defaultAllowAlarms) { mutableStateOf(defaultAllowAlarms) }
    var muteMedia by remember(defaultMuteMedia) { mutableStateOf(defaultMuteMedia) }
    var showDurationError by remember { mutableStateOf(false) }
    val totalMinutes = hours * 60 + minutes

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        AppHeader(onSettings)

        if (!hasDndAccess) {
            Spacer(Modifier.height(10.dp))
            PermissionCard(
                title = "Allow Do Not Disturb access",
                detail = "Required to silence and restore your phone.",
                action = "Allow",
                onClick = onGrantDndAccess,
            )
        } else if (!hasExactAlarmAccess) {
            Spacer(Modifier.height(10.dp))
            PermissionCard(
                title = "Allow precise timer endings",
                detail = "Recommended so sound returns at the exact minute.",
                action = "Allow",
                onClick = onGrantExactAlarmAccess,
            )
        }

        OutlinedButton(
            onClick = onSchedules,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        ) {
            Text("◷  Schedules", modifier = Modifier.weight(1f), textAlign = TextAlign.Start)
            Text(if (enabledScheduleCount == 1) "1 active  ›" else "$enabledScheduleCount active  ›")
        }

        Spacer(Modifier.height(12.dp))
        SectionLabel("SILENCE OPTIONS")
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                OptionRow("▥", "Allow vibration", "Calls and notifications may vibrate", allowVibration) {
                    allowVibration = it
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                OptionRow("◷", "Allow alarms", "Scheduled alarms can still ring", allowAlarms) {
                    allowAlarms = it
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                OptionRow("♪", "Mute media", "Music, videos, and games are muted", muteMedia) {
                    muteMedia = it
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            SectionLabel("QUICK PRESETS")
            Text(
                "Edit  ✎",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 12.sp,
                modifier = Modifier.clickable(onClick = onSettings),
            )
        }
        PresetGrid(presets, totalMinutes) { selected ->
            hours = selected / 60
            minutes = selected % 60
            showDurationError = false
        }

        Spacer(Modifier.height(14.dp))
        EndTimeLine(totalMinutes, timeFormatMode)
        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            WheelPicker(
                label = "HOURS",
                values = (0..23).toList(),
                selectedValue = hours,
                formatter = Int::toString,
                onSelected = { hours = it; showDurationError = false },
                modifier = Modifier.weight(1f),
            )
            Text(
                ":",
                fontSize = 38.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            WheelPicker(
                label = "MINUTES",
                values = (0..55 step 5).toList(),
                selectedValue = minutes,
                formatter = { it.toString().padStart(2, '0') },
                onSelected = { minutes = it; showDurationError = false },
                modifier = Modifier.weight(1f),
            )
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                if (totalMinutes < 5) showDurationError = true
                else onStart(totalMinutes, allowVibration, allowAlarms, muteMedia)
            },
            enabled = hasDndAccess,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(18.dp),
        ) { Text("Start Do Not Disturb", fontWeight = FontWeight.SemiBold) }

        if (showDurationError) {
            Text(
                "Choose at least 5 minutes.",
                color = MaterialTheme.colorScheme.error,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            )
        }
    }
}

@Composable
private fun AppHeader(onSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().height(52.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text("DND Timer", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "⚙",
            fontSize = 24.sp,
            modifier = Modifier.clickable(onClick = onSettings).padding(10.dp),
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.1.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(bottom = 7.dp),
    )
}

@Composable
private fun PresetGrid(presets: List<Int>, selected: Int, onSelect: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        presets.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { value ->
                    val isSelected = selected == value
                    OutlinedButton(
                        onClick = { onSelect(value) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(22.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                            contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurface,
                        ),
                    ) { Text(formatDuration(value), maxLines = 1, fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
private fun WheelPicker(
    label: String,
    values: List<Int>,
    selectedValue: Int,
    formatter: (Int) -> String,
    onSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val initialIndex = values.indexOf(selectedValue).coerceAtLeast(0)
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = initialIndex)
    val flingBehavior = rememberSnapFlingBehavior(lazyListState = listState)

    LaunchedEffect(selectedValue) {
        val target = values.indexOf(selectedValue)
        if (target >= 0 && target != listState.firstVisibleItemIndex && !listState.isScrollInProgress) {
            // Presets must update the wheel atomically. Animating through the
            // intermediate rows causes snapshotFlow to report (and select)
            // values such as 10 while moving to 15.
            listState.scrollToItem(target)
        }
    }

    LaunchedEffect(listState, values) {
        snapshotFlow {
            val layout = listState.layoutInfo
            val center = (layout.viewportStartOffset + layout.viewportEndOffset) / 2
            layout.visibleItemsInfo.minByOrNull { item ->
                kotlin.math.abs((item.offset + item.size / 2) - center)
            }?.index
        }.distinctUntilChanged().collect { index ->
            index?.let { values.getOrNull(it)?.let(onSelected) }
        }
    }

    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        SectionLabel(label)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(168.dp)
                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(20.dp)),
            contentAlignment = Alignment.Center,
        ) {
            LazyColumn(
                state = listState,
                flingBehavior = flingBehavior,
                contentPadding = PaddingValues(vertical = 56.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                itemsIndexed(values) { _, value ->
                    val isSelected = value == selectedValue
                    Box(
                        modifier = Modifier.fillMaxWidth().height(56.dp).clickable { onSelected(value) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            formatter(value),
                            fontSize = if (isSelected) 38.sp else 24.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.alpha(if (isSelected) 1f else 0.38f),
                        )
                    }
                }
            }
            Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(Modifier.height(55.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    }
}

@Composable
private fun OptionRow(
    symbol: String,
    title: String,
    detail: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().height(64.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(symbol, color = MaterialTheme.colorScheme.primary, fontSize = 20.sp, modifier = Modifier.width(34.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(detail, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun EndTimeLine(totalMinutes: Int, timeFormatMode: TimeFormatMode) {
    val context = LocalContext.current
    val endAt = remember(totalMinutes) { System.currentTimeMillis() + totalMinutes * 60_000L }
    val formatted = remember(endAt, timeFormatMode) { formatClockTime(context, endAt, timeFormatMode) }
    Text(
        "Sound returns at $formatted",
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        fontSize = 14.sp,
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun PermissionCard(title: String, detail: String, action: String, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(detail, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedButton(onClick = onClick) { Text(action) }
        }
    }
}

@Composable
private fun ActiveTimerScreen(
    state: TimerState,
    timeFormatMode: TimeFormatMode,
    onSettings: () -> Unit,
    onExtend: (Int) -> Unit,
    onEndRequested: () -> Unit,
    onTimerExpired: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(state.endAtMillis) {
        while (System.currentTimeMillis() < state.endAtMillis) {
            now = System.currentTimeMillis()
            delay(1_000)
        }
        now = System.currentTimeMillis()
        onTimerExpired()
    }

    val remainingMillis = (state.endAtMillis - now).coerceAtLeast(0L)
    val remainingSeconds = (remainingMillis + 999L) / 1_000L
    val hours = remainingSeconds / 3_600
    val minutes = (remainingSeconds % 3_600) / 60
    val seconds = remainingSeconds % 60
    val remainingText = if (hours > 0) {
        "$hours:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}"
    } else {
        "$minutes:${seconds.toString().padStart(2, '0')}"
    }
    val duration = (state.endAtMillis - state.startedAtMillis).coerceAtLeast(1L)
    val progress = (remainingMillis.toFloat() / duration).coerceIn(0f, 1f)
    val context = LocalContext.current
    val untilText = remember(state.endAtMillis, timeFormatMode) {
        formatClockTime(context, state.endAtMillis, timeFormatMode)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        AppHeader(onSettings)
        Text(
            "☾  DO NOT DISTURB ACTIVE",
            color = MaterialTheme.colorScheme.primary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(30.dp))
                .padding(horizontal = 18.dp, vertical = 9.dp),
        )

        Spacer(Modifier.height(18.dp))
        Box(Modifier.size(250.dp).align(Alignment.CenterHorizontally), contentAlignment = Alignment.Center) {
            val primary = MaterialTheme.colorScheme.primary
            val track = MaterialTheme.colorScheme.surfaceVariant
            Canvas(Modifier.fillMaxSize()) {
                drawArc(track, -90f, 360f, false, style = Stroke(14.dp.toPx(), cap = StrokeCap.Round))
                drawArc(primary, -90f, 360f * progress, false, style = Stroke(14.dp.toPx(), cap = StrokeCap.Round))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(remainingText, fontSize = 46.sp, fontWeight = FontWeight.Bold)
                Text("remaining", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(
            "Sound returns at $untilText",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            fontSize = 15.sp,
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
        )

        Spacer(Modifier.height(18.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(15.dp)) {
                SectionLabel("CURRENT SILENCE OPTIONS")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    StatusItem(if (state.allowVibration) "Vibration allowed" else "Vibration blocked")
                    StatusItem(if (state.allowAlarms) "Alarms allowed" else "Alarms blocked")
                }
                StatusItem(
                    if (state.muteMedia) "Media muted" else "Media sound unchanged",
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp),
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        SectionLabel("EXTEND TIMER")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15 to "+15 min", 30 to "+30 min", 60 to "+1 hour").forEach { (value, label) ->
                OutlinedButton(
                    onClick = { onExtend(value) },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 11.dp, horizontal = 2.dp),
                    shape = RoundedCornerShape(14.dp),
                ) { Text(label, fontSize = 12.sp) }
            }
        }

        Spacer(Modifier.height(16.dp))
        OutlinedButton(
            onClick = onEndRequested,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
        ) { Text("■   End Do Not Disturb", fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
private fun StatusItem(text: String, modifier: Modifier = Modifier) {
    Text("✓  $text", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, modifier = modifier)
}

@Composable
private fun SettingsScreen(
    defaults: Triple<Boolean, Boolean, Boolean>,
    presets: List<Int>,
    themeMode: ThemeMode,
    timeFormatMode: TimeFormatMode,
    onBack: () -> Unit,
    onSaveDefaults: (Boolean, Boolean, Boolean) -> Unit,
    onSavePresets: (List<Int>) -> Unit,
    onThemeModeChange: (ThemeMode) -> Unit,
    onTimeFormatModeChange: (TimeFormatMode) -> Unit,
    onOpenAppSettings: () -> Unit,
    onOpenBatterySettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var allowVibration by remember(defaults) { mutableStateOf(defaults.first) }
    var allowAlarms by remember(defaults) { mutableStateOf(defaults.second) }
    var muteMedia by remember(defaults) { mutableStateOf(defaults.third) }
    var editingIndex by remember { mutableStateOf<Int?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(52.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("‹", fontSize = 38.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 14.dp))
            Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(8.dp))
        SectionLabel("APPEARANCE")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.entries.forEach { mode ->
                FilterChip(
                    selected = themeMode == mode,
                    onClick = { onThemeModeChange(mode) },
                    label = { Text(mode.name.lowercase().replaceFirstChar(Char::uppercase)) },
                    modifier = Modifier.weight(1f),
                )
            }
        }

        Spacer(Modifier.height(18.dp))
        SectionLabel("TIME FORMAT")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TimeFormatMode.entries.forEach { mode ->
                val label = when (mode) {
                    TimeFormatMode.SYSTEM -> "System"
                    TimeFormatMode.TWELVE_HOUR -> "12 hour"
                    TimeFormatMode.TWENTY_FOUR_HOUR -> "24 hour"
                }
                FilterChip(
                    selected = timeFormatMode == mode,
                    onClick = { onTimeFormatModeChange(mode) },
                    label = { Text(label, maxLines = 1) },
                    modifier = Modifier.weight(1f),
                )
            }
        }

        Spacer(Modifier.height(18.dp))
        SectionLabel("DEFAULT SILENCE OPTIONS")
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                OptionRow("▥", "Allow vibration", "Notifications and calls may vibrate", allowVibration) {
                    allowVibration = it
                    onSaveDefaults(it, allowAlarms, muteMedia)
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                OptionRow("◷", "Allow alarms", "Scheduled alarms can ring", allowAlarms) {
                    allowAlarms = it
                    onSaveDefaults(allowVibration, it, muteMedia)
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                OptionRow("♪", "Mute media", "Music, videos, and games are muted", muteMedia) {
                    muteMedia = it
                    onSaveDefaults(allowVibration, allowAlarms, it)
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        SectionLabel("QUICK PRESETS")
        Text(
            "Tap a preset to edit it. Use the arrows to reorder the six presets shown on the timer.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 10.dp),
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(horizontal = 12.dp)) {
                presets.forEachIndexed { index, value ->
                    if (index > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Row(
                        modifier = Modifier.fillMaxWidth().height(55.dp).clickable { editingIndex = index },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("☷", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 20.sp)
                        Text(formatDurationLong(value), modifier = Modifier.weight(1f).padding(start = 12.dp))
                        TextButton(
                            onClick = {
                                if (index > 0) onSavePresets(presets.toMutableList().apply {
                                    add(index - 1, removeAt(index))
                                })
                            },
                            enabled = index > 0,
                            contentPadding = PaddingValues(4.dp),
                        ) { Text("↑") }
                        TextButton(
                            onClick = {
                                if (index < presets.lastIndex) onSavePresets(presets.toMutableList().apply {
                                    add(index + 1, removeAt(index))
                                })
                            },
                            enabled = index < presets.lastIndex,
                            contentPadding = PaddingValues(4.dp),
                        ) { Text("↓") }
                        Text("›", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        TextButton(
            onClick = { onSavePresets(AppPreferences.DEFAULT_PRESETS) },
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp),
        ) { Text("Restore default presets") }

        Spacer(Modifier.height(20.dp))
        SectionLabel("KEEP TIMERS RELIABLE")
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    "Some phones restrict apps that have not been opened recently. Check these settings so Android can restore sound when the timer ends.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                ReliabilityTip(
                    number = "1",
                    title = "Keep the app active",
                    detail = "In App info, turn off ‘Manage app if unused’, ‘Pause app activity if unused’, or similar.",
                )
                ReliabilityTip(
                    number = "2",
                    title = "Allow background activity",
                    detail = "Under Battery, choose Unrestricted or allow the app to run in the background.",
                )
                ReliabilityTip(
                    number = "3",
                    title = "Keep timer permissions enabled",
                    detail = "Allow notifications and Alarms & reminders. Setting names vary by phone.",
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedButton(
                        onClick = onOpenAppSettings,
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                    ) { Text("App info", fontSize = 12.sp) }
                    OutlinedButton(
                        onClick = onOpenBatterySettings,
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                    ) { Text("Battery settings", fontSize = 12.sp) }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    editingIndex?.let { index ->
        PresetEditorDialog(
            initialMinutes = presets[index],
            onDismiss = { editingIndex = null },
            onSave = { value ->
                onSavePresets(presets.toMutableList().apply { this[index] = value })
                editingIndex = null
            },
        )
    }
}

@Composable
private fun ScheduleListScreen(
    schedules: List<DndSchedule>,
    timeFormatMode: TimeFormatMode,
    onBack: () -> Unit,
    onAdd: () -> Unit,
    onEdit: (DndSchedule) -> Unit,
    onSetEnabled: (Long, Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().height(52.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("‹", fontSize = 38.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 14.dp))
            Text("Schedules", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(
                "+",
                fontSize = 34.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clickable(onClick = onAdd).padding(horizontal = 10.dp),
            )
        }

        Spacer(Modifier.height(10.dp))
        if (schedules.isEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("No schedules yet", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Add a repeating time for Do Not Disturb.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 5.dp, bottom = 12.dp),
                    )
                    Button(onClick = onAdd) { Text("Add schedule") }
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(schedules, key = { _, item -> item.id }) { _, schedule ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().clickable { onEdit(schedule) },
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(schedule.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                Text(
                                    "${formatMinuteOfDay(LocalContext.current, schedule.startMinute, timeFormatMode)} – " +
                                        "${formatMinuteOfDay(LocalContext.current, schedule.endMinute, timeFormatMode)}  ·  " +
                                        formatScheduleDays(schedule.dayMask),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(top = 3.dp),
                                )
                            }
                            Switch(
                                checked = schedule.enabled,
                                onCheckedChange = { onSetEnabled(schedule.id, it) },
                            )
                        }
                    }
                }
                item { Spacer(Modifier.height(10.dp)) }
            }
        }
    }
}

@Composable
private fun ScheduleEditorScreen(
    schedule: DndSchedule?,
    timeFormatMode: TimeFormatMode,
    onBack: () -> Unit,
    onSave: (DndSchedule) -> Unit,
    onDelete: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var title by remember(schedule?.id) { mutableStateOf(schedule?.title.orEmpty()) }
    var startMinute by remember(schedule?.id) { mutableIntStateOf(schedule?.startMinute ?: 22 * 60) }
    var endMinute by remember(schedule?.id) { mutableIntStateOf(schedule?.endMinute ?: 7 * 60) }
    var dayMask by remember(schedule?.id) { mutableIntStateOf(schedule?.dayMask ?: 0b0011111) }
    var enabled by remember(schedule?.id) { mutableStateOf(schedule?.enabled ?: true) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    val valid = title.trim().isNotEmpty() && dayMask != 0 && startMinute != endMinute

    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(52.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("‹", fontSize = 38.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 14.dp))
            Text(
                if (schedule == null) "Add schedule" else "Edit schedule",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            TextButton(
                enabled = valid,
                onClick = {
                    onSave(
                        DndSchedule(
                            id = schedule?.id ?: System.currentTimeMillis(),
                            title = title.trim(),
                            startMinute = startMinute,
                            endMinute = endMinute,
                            dayMask = dayMask,
                            enabled = enabled,
                        ),
                    )
                },
            ) { Text("Save") }
        }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = title,
            onValueChange = { title = it.take(40) },
            label = { Text("Title") },
            placeholder = { Text("e.g. Weeknights") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(18.dp))
        SectionLabel("TIME")
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(horizontal = 16.dp)) {
                ScheduleTimeRow("From", startMinute, context, timeFormatMode) {
                    showTimePicker(context, startMinute, timeFormatMode) { startMinute = it }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                ScheduleTimeRow("To", endMinute, context, timeFormatMode) {
                    showTimePicker(context, endMinute, timeFormatMode) { endMinute = it }
                }
            }
        }
        if (startMinute == endMinute) {
            Text(
                "Start and end times must be different.",
                color = MaterialTheme.colorScheme.error,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 6.dp),
            )
        } else if (endMinute < startMinute) {
            Text(
                "Ends the following day.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 6.dp),
            )
        }

        Spacer(Modifier.height(20.dp))
        SectionLabel("REPEAT")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ScheduleDays.shortNames.chunked(4).forEachIndexed { rowIndex, row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEachIndexed { columnIndex, label ->
                        val index = rowIndex * 4 + columnIndex
                        FilterChip(
                            selected = dayMask and (1 shl index) != 0,
                            onClick = { dayMask = dayMask xor (1 shl index) },
                            label = { Text(label) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        if (dayMask == 0) {
            Text("Select at least one day.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }

        Spacer(Modifier.height(18.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            OptionRow("◷", "Schedule enabled", "Runs automatically on selected days", enabled) {
                enabled = it
            }
        }

        onDelete?.let {
            Spacer(Modifier.height(18.dp))
            OutlinedButton(
                onClick = { showDeleteConfirmation = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            ) { Text("Delete schedule") }
        }
        Spacer(Modifier.height(16.dp))
    }

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { Text("Delete schedule?") },
            text = { Text("This repeating schedule will be removed.") },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmation = false }) { Text("Cancel") }
            },
            confirmButton = {
                TextButton(
                    onClick = { showDeleteConfirmation = false; onDelete?.invoke() },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                ) { Text("Delete") }
            },
        )
    }
}

@Composable
private fun ScheduleTimeRow(
    label: String,
    minute: Int,
    context: android.content.Context,
    mode: TimeFormatMode,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().height(68.dp).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
        Text(formatMinuteOfDay(context, minute, mode), color = MaterialTheme.colorScheme.primary)
        Text("  ›", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 22.sp)
    }
}

@Composable
private fun ReliabilityTip(number: String, title: String, detail: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(
            number,
            color = MaterialTheme.colorScheme.onPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .size(22.dp)
                .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(11.dp))
                .padding(top = 3.dp),
        )
        Column(Modifier.padding(start = 10.dp)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PresetEditorDialog(initialMinutes: Int, onDismiss: () -> Unit, onSave: (Int) -> Unit) {
    var hours by remember { mutableIntStateOf(initialMinutes / 60) }
    var minutes by remember { mutableIntStateOf((initialMinutes % 60 / 5) * 5) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit preset") },
        text = {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                WheelPicker("HOURS", (0..23).toList(), hours, Int::toString, { hours = it }, Modifier.weight(1f))
                Text(":", fontSize = 32.sp)
                WheelPicker(
                    "MINUTES",
                    (0..55 step 5).toList(),
                    minutes,
                    { it.toString().padStart(2, '0') },
                    { minutes = it },
                    Modifier.weight(1f),
                )
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        confirmButton = {
            TextButton(onClick = { onSave((hours * 60 + minutes).coerceAtLeast(5)) }) { Text("Save") }
        },
    )
}

private fun formatDuration(minutes: Int): String = when {
    minutes < 60 -> "$minutes min"
    minutes % 60 == 0 -> if (minutes == 60) "1 hour" else "${minutes / 60} hours"
    else -> "${minutes / 60}h ${minutes % 60}m"
}

private fun formatDurationLong(minutes: Int): String = when {
    minutes < 60 -> "$minutes minutes"
    minutes % 60 == 0 -> if (minutes == 60) "1 hour" else "${minutes / 60} hours"
    else -> "${minutes / 60} hours ${minutes % 60} minutes"
}

private fun uses24HourTime(context: android.content.Context, mode: TimeFormatMode): Boolean = when (mode) {
    TimeFormatMode.SYSTEM -> DateFormat.is24HourFormat(context)
    TimeFormatMode.TWELVE_HOUR -> false
    TimeFormatMode.TWENTY_FOUR_HOUR -> true
}

private fun formatClockTime(context: android.content.Context, millis: Long, mode: TimeFormatMode): String {
    val pattern = if (uses24HourTime(context, mode)) "HH:mm" else "h:mm a"
    return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(millis))
}

private fun formatMinuteOfDay(
    context: android.content.Context,
    minute: Int,
    mode: TimeFormatMode,
): String {
    val calendar = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, minute / 60)
        set(Calendar.MINUTE, minute % 60)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    return formatClockTime(context, calendar.timeInMillis, mode)
}

private fun formatScheduleDays(mask: Int): String {
    if (mask == ScheduleDays.EVERY_DAY) return "Every day"
    if (mask == 0b0011111) return "Weekdays"
    if (mask == 0b1100000) return "Weekends"
    return ScheduleDays.shortNames.filterIndexed { index, _ -> mask and (1 shl index) != 0 }.joinToString(" ")
}

private fun showTimePicker(
    context: android.content.Context,
    initialMinute: Int,
    mode: TimeFormatMode,
    onSelected: (Int) -> Unit,
) {
    TimePickerDialog(
        context,
        { _, hour, minute -> onSelected(hour * 60 + minute) },
        initialMinute / 60,
        initialMinute % 60,
        uses24HourTime(context, mode),
    ).show()
}
