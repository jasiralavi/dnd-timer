package com.dsynz.dndtimer.timer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.dsynz.dndtimer.schedule.ScheduleManager

class RestoreReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val appContext = context.applicationContext
        TimerManager(appContext).reconcile()
        ScheduleManager(appContext).reconcile()
    }
}
