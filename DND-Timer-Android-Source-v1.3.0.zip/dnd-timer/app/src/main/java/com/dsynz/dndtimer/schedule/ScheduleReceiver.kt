package com.dsynz.dndtimer.schedule

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ScheduleAlarmScheduler.ACTION_START_SCHEDULE) {
            ScheduleManager(context.applicationContext).reconcile()
        }
    }
}
