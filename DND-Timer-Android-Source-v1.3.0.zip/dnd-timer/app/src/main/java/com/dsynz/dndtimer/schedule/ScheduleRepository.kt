package com.dsynz.dndtimer.schedule

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ScheduleRepository(context: Context) {
    private val preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun schedules(): List<DndSchedule> {
        val raw = preferences.getString(KEY_SCHEDULES, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    add(
                        DndSchedule(
                            id = item.getLong("id"),
                            title = item.optString("title", "Schedule"),
                            startMinute = item.getInt("start"),
                            endMinute = item.getInt("end"),
                            dayMask = item.getInt("days"),
                            enabled = item.optBoolean("enabled", true),
                        ),
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun save(schedule: DndSchedule) {
        val current = schedules().toMutableList()
        val index = current.indexOfFirst { it.id == schedule.id }
        if (index >= 0) current[index] = schedule else current.add(schedule)
        write(current)
    }

    fun delete(id: Long) = write(schedules().filterNot { it.id == id })

    fun setEnabled(id: Long, enabled: Boolean) {
        write(schedules().map { if (it.id == id) it.copy(enabled = enabled) else it })
    }

    private fun write(values: List<DndSchedule>) {
        val array = JSONArray()
        values.forEach { schedule ->
            array.put(
                JSONObject()
                    .put("id", schedule.id)
                    .put("title", schedule.title)
                    .put("start", schedule.startMinute)
                    .put("end", schedule.endMinute)
                    .put("days", schedule.dayMask)
                    .put("enabled", schedule.enabled),
            )
        }
        preferences.edit().putString(KEY_SCHEDULES, array.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "dnd_schedule_state"
        private const val KEY_SCHEDULES = "schedules"
    }
}
