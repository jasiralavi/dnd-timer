package com.dsynz.dndtimer.schedule

data class DndSchedule(
    val id: Long,
    val title: String,
    val startMinute: Int,
    val endMinute: Int,
    val dayMask: Int,
    val enabled: Boolean,
) {
    fun runsOn(dayIndex: Int): Boolean = dayMask and (1 shl dayIndex) != 0
}

object ScheduleDays {
    val shortNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    const val EVERY_DAY = 0b1111111
}
