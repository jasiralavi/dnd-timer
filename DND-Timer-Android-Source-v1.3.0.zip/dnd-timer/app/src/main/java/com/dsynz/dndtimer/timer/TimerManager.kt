package com.dsynz.dndtimer.timer

import android.content.Context
import com.dsynz.dndtimer.quicktile.DndTileService
import com.dsynz.dndtimer.widget.DndTimerWidgetProvider

class TimerManager(private val context: Context) {
    private val repository = TimerRepository(context)
    private val dndController = DndController(context)
    private val alarmScheduler = AlarmScheduler(context)
    private val notification = TimerNotification(context)

    fun state(): TimerState = repository.state()

    fun start(
        durationMinutes: Int,
        allowVibration: Boolean,
        allowAlarms: Boolean,
        muteMedia: Boolean,
    ): StartResult {
        if (!dndController.hasPolicyAccess) return StartResult.MissingDndAccess
        if (durationMinutes <= 0) return StartResult.Failed

        val now = System.currentTimeMillis()
        return startUntil(now + durationMinutes * 60_000L, allowVibration, allowAlarms, muteMedia)
    }

    fun startUntil(
        endAtMillis: Long,
        allowVibration: Boolean,
        allowAlarms: Boolean,
        muteMedia: Boolean,
    ): StartResult {
        if (!dndController.hasPolicyAccess) return StartResult.MissingDndAccess
        if (endAtMillis <= System.currentTimeMillis()) return StartResult.Failed

        val existing = repository.state()
        if (existing.isActive) {
            val newEnd = maxOf(existing.endAtMillis, endAtMillis)
            repository.updateEndAt(newEnd)
            alarmScheduler.schedule(newEnd)
            notification.show(repository.state())
            refreshSurfaces()
            return StartResult.Started
        }

        val previousFilter = dndController.currentFilter()
        val previousRinger = dndController.currentRingerMode()
        val previousAlarmVolume = dndController.currentAlarmVolume()
        val previousMediaVolume = dndController.currentMediaVolume()
        if (!dndController.apply(allowVibration, allowAlarms, muteMedia)) return StartResult.Failed

        val startedAtMillis = System.currentTimeMillis()
        repository.begin(
            startedAtMillis = startedAtMillis,
            endAtMillis = endAtMillis,
            allowVibration = allowVibration,
            allowAlarms = allowAlarms,
            muteMedia = muteMedia,
            previousFilter = previousFilter,
            previousRingerMode = previousRinger,
            previousAlarmVolume = previousAlarmVolume,
            previousMediaVolume = previousMediaVolume,
        )
        alarmScheduler.schedule(endAtMillis)
        notification.show(repository.state())
        refreshSurfaces()
        return StartResult.Started
    }

    fun extend(minutes: Int) {
        val current = repository.state()
        if (!current.isActive || minutes <= 0) return
        val newEnd = maxOf(System.currentTimeMillis(), current.endAtMillis) + minutes * 60_000L
        repository.updateEndAt(newEnd)
        alarmScheduler.schedule(newEnd)
        notification.show(repository.state())
        DndTileService.requestRefresh(context)
        DndTimerWidgetProvider.requestUpdate(context)
    }

    fun stop() {
        if (!repository.state().isActive) return
        alarmScheduler.cancel()
        dndController.restore(
            filter = repository.previousFilter(),
            ringerMode = repository.previousRingerMode(),
            alarmVolume = repository.previousAlarmVolume(),
            mediaVolume = repository.previousMediaVolume(),
        )
        repository.finish()
        notification.cancel()
        refreshSurfaces()
    }

    fun reconcile() {
        val current = repository.state()
        if (!current.isActive) return
        if (current.endAtMillis <= System.currentTimeMillis()) {
            stop()
        } else {
            dndController.apply(current.allowVibration, current.allowAlarms, current.muteMedia)
            alarmScheduler.schedule(current.endAtMillis)
            notification.show(current)
        }
    }

    fun hasDndAccess(): Boolean = dndController.hasPolicyAccess

    fun canScheduleExact(): Boolean = alarmScheduler.canScheduleExact()

    private fun refreshSurfaces() {
        DndTileService.requestRefresh(context)
        DndTimerWidgetProvider.requestUpdate(context)
    }
}
