package com.dsynz.dndtimer.schedule

import android.content.Context
import com.dsynz.dndtimer.timer.TimerManager
import com.dsynz.dndtimer.timer.TimerRepository
import java.util.Calendar

class ScheduleManager(private val context: Context) {
    private val repository = ScheduleRepository(context)
    private val alarmScheduler = ScheduleAlarmScheduler(context)

    fun reconcile(now: Long = System.currentTimeMillis()) {
        val enabled = repository.schedules().filter { it.enabled && it.dayMask != 0 }
        val activeEnds = enabled.mapNotNull { activeWindow(it, now)?.second }
        activeEnds.maxOrNull()?.let { endAt ->
            val defaults = TimerRepository(context)
            TimerManager(context).startUntil(
                endAtMillis = endAt,
                allowVibration = defaults.defaultAllowVibration(),
                allowAlarms = defaults.defaultAllowAlarms(),
                muteMedia = defaults.defaultMuteMedia(),
            )
        }
        alarmScheduler.schedule(enabled.mapNotNull { nextStart(it, now) }.minOrNull())
    }

    private fun activeWindow(schedule: DndSchedule, now: Long): Pair<Long, Long>? {
        for (daysBack in 0..1) {
            val start = calendarAt(now).apply {
                add(Calendar.DAY_OF_YEAR, -daysBack)
                val index = dayIndex(get(Calendar.DAY_OF_WEEK))
                if (!schedule.runsOn(index)) return@apply
                set(Calendar.HOUR_OF_DAY, schedule.startMinute / 60)
                set(Calendar.MINUTE, schedule.startMinute % 60)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (!schedule.runsOn(dayIndex(start.get(Calendar.DAY_OF_WEEK)))) continue
            val end = start.clone() as Calendar
            end.set(Calendar.HOUR_OF_DAY, schedule.endMinute / 60)
            end.set(Calendar.MINUTE, schedule.endMinute % 60)
            if (schedule.endMinute <= schedule.startMinute) end.add(Calendar.DAY_OF_YEAR, 1)
            if (now >= start.timeInMillis && now < end.timeInMillis) {
                return start.timeInMillis to end.timeInMillis
            }
        }
        return null
    }

    private fun nextStart(schedule: DndSchedule, now: Long): Long? {
        for (offset in 0..7) {
            val candidate = calendarAt(now).apply {
                add(Calendar.DAY_OF_YEAR, offset)
                set(Calendar.HOUR_OF_DAY, schedule.startMinute / 60)
                set(Calendar.MINUTE, schedule.startMinute % 60)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (schedule.runsOn(dayIndex(candidate.get(Calendar.DAY_OF_WEEK))) && candidate.timeInMillis > now) {
                return candidate.timeInMillis
            }
        }
        return null
    }

    private fun calendarAt(millis: Long) = Calendar.getInstance().apply { timeInMillis = millis }

    private fun dayIndex(calendarDay: Int): Int = when (calendarDay) {
        Calendar.MONDAY -> 0
        Calendar.TUESDAY -> 1
        Calendar.WEDNESDAY -> 2
        Calendar.THURSDAY -> 3
        Calendar.FRIDAY -> 4
        Calendar.SATURDAY -> 5
        else -> 6
    }
}
