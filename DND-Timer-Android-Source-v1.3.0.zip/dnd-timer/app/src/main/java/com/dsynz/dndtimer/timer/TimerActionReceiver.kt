package com.dsynz.dndtimer.timer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class TimerActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val timerManager = TimerManager(context.applicationContext)
        when (intent.action) {
            ACTION_END -> timerManager.stop()
            ACTION_EXTEND_15 -> timerManager.extend(15)
            ACTION_EXTEND_30 -> timerManager.extend(30)
            ACTION_EXTEND_60 -> timerManager.extend(60)
        }
    }

    companion object {
        const val ACTION_END = "com.dsynz.dndtimer.action.END"
        const val ACTION_EXTEND_15 = "com.dsynz.dndtimer.action.EXTEND_15"
        const val ACTION_EXTEND_30 = "com.dsynz.dndtimer.action.EXTEND_30"
        const val ACTION_EXTEND_60 = "com.dsynz.dndtimer.action.EXTEND_60"
    }
}
