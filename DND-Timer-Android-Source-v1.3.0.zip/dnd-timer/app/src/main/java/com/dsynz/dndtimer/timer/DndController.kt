package com.dsynz.dndtimer.timer

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager

class DndController(context: Context) {
    private val notificationManager = context.getSystemService(NotificationManager::class.java)
    private val audioManager = context.getSystemService(AudioManager::class.java)

    val hasPolicyAccess: Boolean
        get() = notificationManager.isNotificationPolicyAccessGranted

    fun currentFilter(): Int = notificationManager.currentInterruptionFilter

    fun currentRingerMode(): Int = audioManager.ringerMode

    fun currentAlarmVolume(): Int = audioManager.getStreamVolume(AudioManager.STREAM_ALARM)

    fun currentMediaVolume(): Int = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)

    fun apply(allowVibration: Boolean, allowAlarms: Boolean, muteMedia: Boolean): Boolean {
        if (!hasPolicyAccess) return false

        return runCatching {
            when {
                allowVibration -> {
                    // Vibrate mode preserves vibration for calls and notifications.
                    // Alarm audio is independently retained or temporarily muted.
                    notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
                    audioManager.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                    if (!allowAlarms) {
                        audioManager.setStreamVolume(AudioManager.STREAM_ALARM, 0, 0)
                    }
                }

                allowAlarms -> {
                    notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS)
                    audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT
                }

                else -> {
                    notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
                    audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT
                }
            }
            if (muteMedia) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
            }
        }.isSuccess
    }

    fun restore(filter: Int, ringerMode: Int, alarmVolume: Int, mediaVolume: Int) {
        if (!hasPolicyAccess) return
        runCatching {
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, alarmVolume, 0)
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, mediaVolume, 0)
            audioManager.ringerMode = ringerMode
            notificationManager.setInterruptionFilter(filter)
        }
    }
}
