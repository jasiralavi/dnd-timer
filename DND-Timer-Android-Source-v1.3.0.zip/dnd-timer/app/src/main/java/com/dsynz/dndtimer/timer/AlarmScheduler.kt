package com.dsynz.dndtimer.timer

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmScheduler(private val context: Context) {
    private val alarmManager = context.getSystemService(AlarmManager::class.java)

    fun canScheduleExact(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    fun schedule(endAtMillis: Long) {
        val pendingIntent = endPendingIntent()
        if (canScheduleExact()) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAtMillis, pendingIntent)
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAtMillis, pendingIntent)
        }
    }

    fun cancel() {
        alarmManager.cancel(endPendingIntent())
    }

    private fun endPendingIntent(): PendingIntent {
        val intent = Intent(context, TimerActionReceiver::class.java).apply {
            action = TimerActionReceiver.ACTION_END
        }
        return PendingIntent.getBroadcast(
            context,
            END_REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    companion object {
        private const val END_REQUEST_CODE = 7001
    }
}
