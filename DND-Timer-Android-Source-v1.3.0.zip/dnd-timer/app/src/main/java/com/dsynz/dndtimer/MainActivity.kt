package com.dsynz.dndtimer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.dsynz.dndtimer.timer.StartResult
import com.dsynz.dndtimer.timer.TimerManager
import com.dsynz.dndtimer.timer.TimerRepository
import com.dsynz.dndtimer.timer.TimerState
import com.dsynz.dndtimer.settings.AppPreferences
import com.dsynz.dndtimer.settings.ThemeMode
import com.dsynz.dndtimer.settings.TimeFormatMode
import com.dsynz.dndtimer.schedule.DndSchedule
import com.dsynz.dndtimer.schedule.ScheduleManager
import com.dsynz.dndtimer.schedule.ScheduleRepository
import com.dsynz.dndtimer.ui.DndTimerApp
import com.dsynz.dndtimer.ui.theme.DndTimerTheme
import com.dsynz.dndtimer.widget.DndTimerWidgetProvider

class MainActivity : ComponentActivity() {
    private lateinit var timerManager: TimerManager
    private lateinit var appPreferences: AppPreferences
    private var timerState by mutableStateOf(TimerState(false, 0L, 0L, false, true, true))
    private var hasDndAccess by mutableStateOf(false)
    private var hasExactAlarmAccess by mutableStateOf(true)
    private var presets by mutableStateOf(AppPreferences.DEFAULT_PRESETS)
    private var themeMode by mutableStateOf(ThemeMode.SYSTEM)
    private var timeFormatMode by mutableStateOf(TimeFormatMode.SYSTEM)
    private var schedules by mutableStateOf(emptyList<DndSchedule>())
    private var endConfirmationRequest by mutableIntStateOf(0)
    private var settingsRequest by mutableIntStateOf(0)

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted && ::timerManager.isInitialized) timerManager.reconcile()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        timerManager = TimerManager(applicationContext)
        appPreferences = AppPreferences(applicationContext)
        timerManager.reconcile()
        ScheduleManager(applicationContext).reconcile()
        refreshState()
        handleIntent(intent)

        setContent {
            DndTimerTheme(themeMode) {
                DndTimerApp(
                    state = timerState,
                    hasDndAccess = hasDndAccess,
                    hasExactAlarmAccess = hasExactAlarmAccess,
                    presets = presets,
                    themeMode = themeMode,
                    timeFormatMode = timeFormatMode,
                    schedules = schedules,
                    endConfirmationRequest = endConfirmationRequest,
                    settingsRequest = settingsRequest,
                    onGrantDndAccess = ::openDndAccessSettings,
                    onGrantExactAlarmAccess = ::openExactAlarmSettings,
                    onStart = ::startTimer,
                    onExtend = { minutes ->
                        timerManager.extend(minutes)
                        refreshState()
                    },
                    onEnd = {
                        timerManager.stop()
                        refreshState()
                    },
                    onSaveDefaults = { vibration, alarms, media ->
                        TimerRepository(applicationContext).saveDefaults(vibration, alarms, media)
                        refreshState()
                        DndTimerWidgetProvider.requestUpdate(applicationContext)
                    },
                    onSavePresets = { values ->
                        appPreferences.savePresets(values)
                        presets = appPreferences.presets()
                        DndTimerWidgetProvider.requestUpdate(applicationContext)
                    },
                    onThemeModeChange = { mode ->
                        appPreferences.saveThemeMode(mode)
                        themeMode = mode
                    },
                    onTimeFormatModeChange = { mode ->
                        appPreferences.saveTimeFormatMode(mode)
                        timeFormatMode = mode
                    },
                    onSaveSchedule = { schedule ->
                        ScheduleRepository(applicationContext).save(schedule)
                        ScheduleManager(applicationContext).reconcile()
                        refreshState()
                    },
                    onDeleteSchedule = { id ->
                        ScheduleRepository(applicationContext).delete(id)
                        ScheduleManager(applicationContext).reconcile()
                        refreshState()
                    },
                    onSetScheduleEnabled = { id, enabled ->
                        ScheduleRepository(applicationContext).setEnabled(id, enabled)
                        ScheduleManager(applicationContext).reconcile()
                        refreshState()
                    },
                    onOpenAppSettings = ::openAppSettings,
                    onOpenBatterySettings = ::openBatterySettings,
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (::timerManager.isInitialized) {
            timerManager.reconcile()
            ScheduleManager(applicationContext).reconcile()
            refreshState()
        }
    }

    private fun startTimer(
        minutes: Int,
        allowVibration: Boolean,
        allowAlarms: Boolean,
        muteMedia: Boolean,
    ) {
        when (timerManager.start(minutes, allowVibration, allowAlarms, muteMedia)) {
            StartResult.Started -> {
                requestNotificationPermissionIfNeeded()
                refreshState()
            }
            StartResult.MissingDndAccess -> openDndAccessSettings()
            StartResult.Failed -> refreshState()
        }
    }

    private fun refreshState() {
        timerState = timerManager.state()
        hasDndAccess = timerManager.hasDndAccess()
        hasExactAlarmAccess = timerManager.canScheduleExact()
        if (::appPreferences.isInitialized) {
            presets = appPreferences.presets()
            themeMode = appPreferences.themeMode()
            timeFormatMode = appPreferences.timeFormatMode()
            schedules = ScheduleRepository(applicationContext).schedules()
        }
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        if (intent.getBooleanExtra(EXTRA_CONFIRM_END, false)) {
            endConfirmationRequest++
            intent.removeExtra(EXTRA_CONFIRM_END)
        }
        if (intent.getBooleanExtra(EXTRA_OPEN_SETTINGS, false)) {
            settingsRequest++
            intent.removeExtra(EXTRA_OPEN_SETTINGS)
        }
        val startMinutes = intent.getIntExtra(EXTRA_START_MINUTES, 0)
        if (startMinutes > 0) {
            val repository = TimerRepository(applicationContext)
            startTimer(
                startMinutes,
                repository.defaultAllowVibration(),
                repository.defaultAllowAlarms(),
                repository.defaultMuteMedia(),
            )
            intent.removeExtra(EXTRA_START_MINUTES)
        }
    }

    private fun openDndAccessSettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        runCatching {
            startActivity(
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                },
            )
        }
    }

    private fun openAppSettings() {
        runCatching {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                },
            )
        }
    }

    private fun openBatterySettings() {
        val appDetails = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
        }
        runCatching {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }.recoverCatching {
            startActivity(appDetails)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    companion object {
        const val EXTRA_OPENED_FROM_TILE = "opened_from_tile"
        const val EXTRA_CONFIRM_END = "confirm_end"
        const val EXTRA_START_MINUTES = "start_minutes"
        const val EXTRA_OPEN_SETTINGS = "open_settings"
    }
}
