# DND Timer does not currently require custom shrinking rules.
