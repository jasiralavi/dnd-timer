package com.dsynz.dndtimer.ui

import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dsynz.dndtimer.timer.TimerState
import kotlinx.coroutines.delay
import java.util.Date

@Composable
fun DndTimerApp(
    state: TimerState,
    hasDndAccess: Boolean,
    hasExactAlarmAccess: Boolean,
    onGrantDndAccess: () -> Unit,
    onGrantExactAlarmAccess: () -> Unit,
    onStart: (minutes: Int, allowVibration: Boolean, allowAlarms: Boolean) -> Unit,
    onExtend: (minutes: Int) -> Unit,
    onEnd: () -> Unit,
) {
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
    ) { innerPadding ->
        if (state.isActive) {
            ActiveTimerScreen(
                state = state,
                onExtend = onExtend,
                onEnd = onEnd,
                modifier = Modifier.padding(innerPadding),
            )
        } else {
            TimerSetupScreen(
                hasDndAccess = hasDndAccess,
                hasExactAlarmAccess = hasExactAlarmAccess,
                defaultAllowVibration = state.allowVibration,
                defaultAllowAlarms = state.allowAlarms,
                onGrantDndAccess = onGrantDndAccess,
                onGrantExactAlarmAccess = onGrantExactAlarmAccess,
                onStart = onStart,
                modifier = Modifier.padding(innerPadding),
            )
        }
    }
}

@Composable
private fun TimerSetupScreen(
    hasDndAccess: Boolean,
    hasExactAlarmAccess: Boolean,
    defaultAllowVibration: Boolean,
    defaultAllowAlarms: Boolean,
    onGrantDndAccess: () -> Unit,
    onGrantExactAlarmAccess: () -> Unit,
    onStart: (Int, Boolean, Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    var hours by remember { mutableIntStateOf(1) }
    var minutes by remember { mutableIntStateOf(0) }
    var allowVibration by remember(defaultAllowVibration) { mutableStateOf(defaultAllowVibration) }
    var allowAlarms by remember(defaultAllowAlarms) { mutableStateOf(defaultAllowAlarms) }
    var showDurationError by remember { mutableStateOf(false) }
    val totalMinutes = hours * 60 + minutes

    Column(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 18.dp),
    ) {
        Text(
            text = "DND TIMER",
            color = MaterialTheme.colorScheme.primary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 1.4.sp,
        )
        Text(
            text = "How long?",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Medium,
        )

        if (!hasDndAccess) {
            Spacer(Modifier.height(14.dp))
            PermissionCard(
                title = "Allow Do Not Disturb access",
                detail = "Required to silence and restore your phone.",
                action = "Allow",
                onClick = onGrantDndAccess,
            )
        } else if (!hasExactAlarmAccess) {
            Spacer(Modifier.height(14.dp))
            PermissionCard(
                title = "Allow precise timer endings",
                detail = "Recommended so sound returns at the exact minute.",
                action = "Allow",
                onClick = onGrantExactAlarmAccess,
            )
        }

        Spacer(Modifier.height(14.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            NumberControl(
                value = hours,
                label = "hours",
                max = 23,
                onValueChange = { hours = it; showDurationError = false },
                modifier = Modifier.weight(1f),
            )
            Text(
                text = ":",
                fontSize = 38.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 3.dp),
            )
            NumberControl(
                value = minutes,
                label = "minutes",
                max = 59,
                step = 5,
                onValueChange = { minutes = it; showDurationError = false },
                modifier = Modifier.weight(1f),
            )
        }

        Spacer(Modifier.height(10.dp))
        PresetRow(totalMinutes = totalMinutes) { selected ->
            hours = selected / 60
            minutes = selected % 60
            showDurationError = false
        }

        Spacer(Modifier.height(24.dp))
        Text("What can interrupt?", fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(5.dp))
        OptionRow(
            symbol = "〰",
            title = "Allow vibration",
            detail = "Calls and notifications may vibrate",
            checked = allowVibration,
            onCheckedChange = { allowVibration = it },
        )
        OptionRow(
            symbol = "◷",
            title = "Allow alarms",
            detail = "Scheduled alarms can still ring",
            checked = allowAlarms,
            onCheckedChange = { allowAlarms = it },
        )

        Spacer(Modifier.height(16.dp))
        EndTimeCard(totalMinutes)
        Spacer(Modifier.height(14.dp))

        Button(
            onClick = {
                if (totalMinutes < 5) showDurationError = true
                else onStart(totalMinutes, allowVibration, allowAlarms)
            },
            enabled = hasDndAccess,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(18.dp),
        ) {
            Text("☾", fontSize = 23.sp)
            Spacer(Modifier.width(8.dp))
            Text("Start Do Not Disturb", fontWeight = FontWeight.Medium)
        }

        if (showDurationError) {
            Text(
                text = "Choose at least 5 minutes.",
                color = MaterialTheme.colorScheme.error,
                fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
                textAlign = TextAlign.Center,
            )
        }

        Spacer(Modifier.height(12.dp))
        Text(
            text = if (hasDndAccess) "DND access granted" else "DND access is required",
            color = if (hasDndAccess) Color(0xFF27865F) else MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
        )
    }
}

@Composable
private fun NumberControl(
    value: Int,
    label: String,
    max: Int,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
    step: Int = 1,
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        OutlinedButton(
            onClick = { onValueChange((value + step).coerceAtMost(max)) },
            shape = CircleShape,
            contentPadding = PaddingValues(0.dp),
            modifier = Modifier.size(40.dp),
        ) { Text("+") }
        OutlinedTextField(
            value = value.toString(),
            onValueChange = { raw ->
                raw.filter(Char::isDigit).toIntOrNull()?.let { onValueChange(it.coerceIn(0, max)) }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            textStyle = MaterialTheme.typography.displaySmall.copy(textAlign = TextAlign.Center),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 7.dp),
        )
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        OutlinedButton(
            onClick = { onValueChange((value - step).coerceAtLeast(0)) },
            shape = CircleShape,
            contentPadding = PaddingValues(0.dp),
            modifier = Modifier.size(40.dp),
        ) { Text("−") }
    }
}

@Composable
private fun PresetRow(totalMinutes: Int, onSelect: (Int) -> Unit) {
    val presets = listOf(15 to "15 min", 30 to "30 min", 60 to "1 hour", 120 to "2 hours")
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        presets.forEach { (value, label) ->
            val selected = totalMinutes == value
            OutlinedButton(
                onClick = { onSelect(value) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(22.dp),
                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 10.dp),
                colors = if (selected) {
                    ButtonDefaults.outlinedButtonColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                } else ButtonDefaults.outlinedButtonColors(),
            ) { Text(label, maxLines = 1, fontSize = 12.sp) }
        }
    }
}

@Composable
private fun OptionRow(
    symbol: String,
    title: String,
    detail: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().height(62.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(11.dp)),
            contentAlignment = Alignment.Center,
        ) { Text(symbol, color = MaterialTheme.colorScheme.primary, fontSize = 19.sp) }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(detail, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun EndTimeCard(totalMinutes: Int) {
    val context = LocalContext.current
    val endAt = remember(totalMinutes) { System.currentTimeMillis() + totalMinutes * 60_000L }
    val formatted = remember(endAt) { DateFormat.getTimeFormat(context).format(Date(endAt)) }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("Silent until", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Text(formatted, fontWeight = FontWeight.Medium, fontSize = 14.sp)
        }
    }
}

@Composable
private fun PermissionCard(
    title: String,
    detail: String,
    action: String,
    onClick: () -> Unit,
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(detail, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedButton(onClick = onClick) { Text(action) }
        }
    }
}

@Composable
private fun ActiveTimerScreen(
    state: TimerState,
    onExtend: (Int) -> Unit,
    onEnd: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(state.endAtMillis) {
        while (System.currentTimeMillis() < state.endAtMillis) {
            now = System.currentTimeMillis()
            delay(1_000)
        }
        now = System.currentTimeMillis()
        onEnd()
    }

    val remainingMinutes = ((state.endAtMillis - now).coerceAtLeast(0L) + 59_999L) / 60_000L
    val hours = remainingMinutes / 60
    val minutes = remainingMinutes % 60
    val remainingText = if (hours > 0) "$hours hr ${minutes.toString().padStart(2, '0')} min" else "$minutes min"
    val context = LocalContext.current
    val untilText = remember(state.endAtMillis) {
        DateFormat.getTimeFormat(context).format(Date(state.endAtMillis))
    }
    val interruptions = buildList {
        if (state.allowVibration) add("Vibration")
        if (state.allowAlarms) add("Alarms")
    }.ifEmpty { listOf("Nothing — total silence") }.joinToString(" • ")

    Column(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 18.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(
                    "DO NOT DISTURB",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.4.sp,
                )
                Text("Quiet time", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Medium)
            }
            Text(
                "●  Active",
                color = Color(0xFF27865F),
                fontSize = 12.sp,
                modifier = Modifier
                    .background(Color(0x1A27865F), RoundedCornerShape(20.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            )
        }

        Spacer(Modifier.height(45.dp))
        Box(
            modifier = Modifier
                .size(116.dp)
                .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                .align(Alignment.CenterHorizontally),
            contentAlignment = Alignment.Center,
        ) { Text("☾", fontSize = 57.sp, color = MaterialTheme.colorScheme.primary) }

        Spacer(Modifier.height(24.dp))
        Text(
            "Remaining",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )
        Text(
            remainingText,
            fontSize = 36.sp,
            fontWeight = FontWeight.Normal,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )
        Text(
            "Until $untilText",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )

        Spacer(Modifier.height(35.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(17.dp)) {
                Text("Allowed interruptions", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(interruptions, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
        }

        Spacer(Modifier.height(25.dp))
        Text("Need more time?", fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(9.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15 to "+15 min", 30 to "+30 min", 60 to "+1 hour").forEach { (value, label) ->
                OutlinedButton(
                    onClick = { onExtend(value) },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 10.dp, horizontal = 2.dp),
                    shape = RoundedCornerShape(14.dp),
                ) { Text(label, fontSize = 12.sp) }
            }
        }

        Spacer(Modifier.height(36.dp))
        OutlinedButton(
            onClick = onEnd,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(18.dp),
        ) { Text("End now", fontWeight = FontWeight.Medium) }
        Text(
            "Sound will return automatically when the timer ends.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 11.dp),
        )
    }
}
