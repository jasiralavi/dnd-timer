package com.dsynz.dndtimer.timer

import android.content.Context
import com.dsynz.dndtimer.quicktile.DndTileService

class TimerManager(private val context: Context) {
    private val repository = TimerRepository(context)
    private val dndController = DndController(context)
    private val alarmScheduler = AlarmScheduler(context)
    private val notification = TimerNotification(context)

    fun state(): TimerState = repository.state()

    fun start(durationMinutes: Int, allowVibration: Boolean, allowAlarms: Boolean): StartResult {
        if (!dndController.hasPolicyAccess) return StartResult.MissingDndAccess
        if (durationMinutes <= 0) return StartResult.Failed

        if (repository.state().isActive) stop()

        val previousFilter = dndController.currentFilter()
        val previousRinger = dndController.currentRingerMode()
        val previousAlarmVolume = dndController.currentAlarmVolume()
        if (!dndController.apply(allowVibration, allowAlarms)) return StartResult.Failed

        val endAtMillis = System.currentTimeMillis() + durationMinutes * 60_000L
        repository.begin(
            endAtMillis = endAtMillis,
            allowVibration = allowVibration,
            allowAlarms = allowAlarms,
            previousFilter = previousFilter,
            previousRingerMode = previousRinger,
            previousAlarmVolume = previousAlarmVolume,
        )
        alarmScheduler.schedule(endAtMillis)
        notification.show(repository.state())
        DndTileService.requestRefresh(context)
        return StartResult.Started
    }

    fun extend(minutes: Int) {
        val current = repository.state()
        if (!current.isActive || minutes <= 0) return
        val newEnd = maxOf(System.currentTimeMillis(), current.endAtMillis) + minutes * 60_000L
        repository.updateEndAt(newEnd)
        alarmScheduler.schedule(newEnd)
        notification.show(repository.state())
        DndTileService.requestRefresh(context)
    }

    fun stop() {
        if (!repository.state().isActive) return
        alarmScheduler.cancel()
        dndController.restore(
            filter = repository.previousFilter(),
            ringerMode = repository.previousRingerMode(),
            alarmVolume = repository.previousAlarmVolume(),
        )
        repository.finish()
        notification.cancel()
        DndTileService.requestRefresh(context)
    }

    fun reconcile() {
        val current = repository.state()
        if (!current.isActive) return
        if (current.endAtMillis <= System.currentTimeMillis()) {
            stop()
        } else {
            dndController.apply(current.allowVibration, current.allowAlarms)
            alarmScheduler.schedule(current.endAtMillis)
            notification.show(current)
        }
    }

    fun hasDndAccess(): Boolean = dndController.hasPolicyAccess

    fun canScheduleExact(): Boolean = alarmScheduler.canScheduleExact()
}
