package com.dsynz.dndtimer.timer

data class TimerState(
    val isActive: Boolean,
    val endAtMillis: Long,
    val allowVibration: Boolean,
    val allowAlarms: Boolean,
)

enum class StartResult {
    Started,
    MissingDndAccess,
    Failed,
}
