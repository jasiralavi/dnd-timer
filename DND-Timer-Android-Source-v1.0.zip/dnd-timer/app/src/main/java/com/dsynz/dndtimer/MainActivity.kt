package com.dsynz.dndtimer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.dsynz.dndtimer.timer.StartResult
import com.dsynz.dndtimer.timer.TimerManager
import com.dsynz.dndtimer.timer.TimerState
import com.dsynz.dndtimer.ui.DndTimerApp
import com.dsynz.dndtimer.ui.theme.DndTimerTheme

class MainActivity : ComponentActivity() {
    private lateinit var timerManager: TimerManager
    private var timerState by mutableStateOf(TimerState(false, 0L, false, true))
    private var hasDndAccess by mutableStateOf(false)
    private var hasExactAlarmAccess by mutableStateOf(true)

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted && ::timerManager.isInitialized) timerManager.reconcile()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        timerManager = TimerManager(applicationContext)
        timerManager.reconcile()
        refreshState()

        setContent {
            DndTimerTheme {
                DndTimerApp(
                    state = timerState,
                    hasDndAccess = hasDndAccess,
                    hasExactAlarmAccess = hasExactAlarmAccess,
                    onGrantDndAccess = ::openDndAccessSettings,
                    onGrantExactAlarmAccess = ::openExactAlarmSettings,
                    onStart = ::startTimer,
                    onExtend = { minutes ->
                        timerManager.extend(minutes)
                        refreshState()
                    },
                    onEnd = {
                        timerManager.stop()
                        refreshState()
                    },
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::timerManager.isInitialized) {
            timerManager.reconcile()
            refreshState()
        }
    }

    private fun startTimer(minutes: Int, allowVibration: Boolean, allowAlarms: Boolean) {
        when (timerManager.start(minutes, allowVibration, allowAlarms)) {
            StartResult.Started -> {
                requestNotificationPermissionIfNeeded()
                refreshState()
            }
            StartResult.MissingDndAccess -> openDndAccessSettings()
            StartResult.Failed -> refreshState()
        }
    }

    private fun refreshState() {
        timerState = timerManager.state()
        hasDndAccess = timerManager.hasDndAccess()
        hasExactAlarmAccess = timerManager.canScheduleExact()
    }

    private fun openDndAccessSettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        runCatching {
            startActivity(
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                },
            )
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    companion object {
        const val EXTRA_OPENED_FROM_TILE = "opened_from_tile"
    }
}
