package com.dsynz.dndtimer.timer

import android.content.Context

class TimerRepository(context: Context) {
    private val preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun state(): TimerState = TimerState(
        isActive = preferences.getBoolean(KEY_ACTIVE, false),
        endAtMillis = preferences.getLong(KEY_END_AT, 0L),
        allowVibration = preferences.getBoolean(KEY_ALLOW_VIBRATION, false),
        allowAlarms = preferences.getBoolean(KEY_ALLOW_ALARMS, true),
    )

    fun defaultAllowVibration(): Boolean = preferences.getBoolean(KEY_ALLOW_VIBRATION, false)

    fun defaultAllowAlarms(): Boolean = preferences.getBoolean(KEY_ALLOW_ALARMS, true)

    fun begin(
        endAtMillis: Long,
        allowVibration: Boolean,
        allowAlarms: Boolean,
        previousFilter: Int,
        previousRingerMode: Int,
        previousAlarmVolume: Int,
    ) {
        preferences.edit()
            .putBoolean(KEY_ACTIVE, true)
            .putLong(KEY_END_AT, endAtMillis)
            .putBoolean(KEY_ALLOW_VIBRATION, allowVibration)
            .putBoolean(KEY_ALLOW_ALARMS, allowAlarms)
            .putInt(KEY_PREVIOUS_FILTER, previousFilter)
            .putInt(KEY_PREVIOUS_RINGER, previousRingerMode)
            .putInt(KEY_PREVIOUS_ALARM_VOLUME, previousAlarmVolume)
            .apply()
    }

    fun updateEndAt(endAtMillis: Long) {
        preferences.edit().putLong(KEY_END_AT, endAtMillis).apply()
    }

    fun previousFilter(): Int = preferences.getInt(KEY_PREVIOUS_FILTER, 1)

    fun previousRingerMode(): Int = preferences.getInt(KEY_PREVIOUS_RINGER, 2)

    fun previousAlarmVolume(): Int = preferences.getInt(KEY_PREVIOUS_ALARM_VOLUME, 1)

    fun finish() {
        preferences.edit()
            .putBoolean(KEY_ACTIVE, false)
            .putLong(KEY_END_AT, 0L)
            .remove(KEY_PREVIOUS_FILTER)
            .remove(KEY_PREVIOUS_RINGER)
            .remove(KEY_PREVIOUS_ALARM_VOLUME)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "dnd_timer_state"
        private const val KEY_ACTIVE = "active"
        private const val KEY_END_AT = "end_at"
        private const val KEY_ALLOW_VIBRATION = "allow_vibration"
        private const val KEY_ALLOW_ALARMS = "allow_alarms"
        private const val KEY_PREVIOUS_FILTER = "previous_filter"
        private const val KEY_PREVIOUS_RINGER = "previous_ringer"
        private const val KEY_PREVIOUS_ALARM_VOLUME = "previous_alarm_volume"
    }
}
