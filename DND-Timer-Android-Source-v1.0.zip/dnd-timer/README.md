# DND Timer

DND Timer is a focused Android utility for silencing a phone for a precise number of minutes or hours. The app restores the user's previous sound and DND state automatically when the timer ends.

## Included in version 1.0

- Separate hour and minute controls
- Presets for 15 minutes, 30 minutes, 1 hour, and 2 hours
- Independent **Allow vibration** and **Allow alarms** switches
- Exact finishing-time preview
- Active countdown screen
- Extend by 15 minutes, 30 minutes, or 1 hour
- End the timer immediately
- Quick Settings tile that opens the timer picker instead of silently starting the last duration
- Active-timer notification with **+15 min** and **End now** actions
- Timer restoration after reboot or application update
- Light, dark, and Android dynamic-colour themes

## Sound behaviour

| Vibration | Alarms | Behaviour |
| --- | --- | --- |
| Off | Off | Total silence |
| Off | On | Only scheduled alarms can make sound |
| On | Off | Calls and notifications may vibrate; alarm audio is temporarily muted |
| On | On | Calls and notifications may vibrate; scheduled alarms can ring |

The app stores the previous DND filter, ringer mode, and alarm volume before starting. These values are restored when the timer ends or the user selects **End now**.

## Android requirements

- Minimum Android version: Android 8.0 (API 26)
- Target Android version: Android 15 (API 35)
- JDK 17
- Android SDK 35
- Android Studio with Gradle support

## Build

1. Open the `dnd-timer` folder in Android Studio.
2. Allow Android Studio to install SDK 35 and sync the Gradle project.
3. Select **Build > Build APK(s)** for a debug APK.
4. The resulting debug APK will be under `app/build/outputs/apk/debug/`.

The source project intentionally does not include a machine-generated Gradle wrapper JAR. Android Studio can configure the local Gradle runtime when importing the project.

## Build on GitHub from a mobile phone

The project includes `.github/workflows/build-apk.yml`. GitHub runs the Android build in the cloud, so Android Studio is not required on the phone.

1. Create a GitHub repository and add the contents of this `dnd-timer` folder at the repository root.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK**.
4. Tap **Run workflow**, select the `main` branch, and confirm.
5. Open the completed workflow run.
6. Under **Artifacts**, download **DND-Timer-APK**.
7. Extract the artifact ZIP and install `DND-Timer-v1.0-debug.apk`.

The workflow also rebuilds the APK automatically whenever source is pushed to the `main` branch. Build artifacts are retained for 14 days.

## First-run setup

1. Open DND Timer.
2. Select **Allow** on the DND access card and enable DND Timer in Android's system screen.
3. Optionally grant precise alarm access. Without it, the app uses Android's inexact idle-safe fallback and the end time may be slightly delayed.
4. Android 13 and later will request notification permission after the first timer starts.
5. To add the Quick Settings tile, edit the device's Quick Settings panel and drag **DND Timer** into the active tiles.

## Project structure

- `MainActivity.kt` — permission routing and app state
- `ui/DndTimerApp.kt` — Compose setup and countdown screens
- `timer/TimerManager.kt` — timer orchestration
- `timer/DndController.kt` — ringer, alarm, and DND state changes
- `timer/AlarmScheduler.kt` — precise/fallback timer expiry
- `timer/TimerNotification.kt` — active-timer notification
- `quicktile/DndTileService.kt` — Quick Settings entry point

## Device compatibility note

Some Android manufacturers customise DND and ringer behaviour. The implementation uses public Android APIs and restores all captured values, but final acceptance testing should cover the intended phones, particularly Samsung, OnePlus/Oppo, Xiaomi, and Pixel devices.
