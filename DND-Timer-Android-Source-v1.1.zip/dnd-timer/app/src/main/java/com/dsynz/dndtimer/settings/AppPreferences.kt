package com.dsynz.dndtimer.settings

import android.content.Context

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK,
}

class AppPreferences(context: Context) {
    private val preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun presets(): List<Int> {
        val saved = preferences.getString(KEY_PRESETS, null)
            ?.split(',')
            ?.mapNotNull(String::toIntOrNull)
            ?.filter { it in 5..1_439 }
        return if (saved?.size == PRESET_COUNT) saved else DEFAULT_PRESETS
    }

    fun savePresets(values: List<Int>) {
        if (values.size != PRESET_COUNT) return
        preferences.edit().putString(KEY_PRESETS, values.joinToString(",")).apply()
    }

    fun restoreDefaultPresets() = savePresets(DEFAULT_PRESETS)

    fun themeMode(): ThemeMode = runCatching {
        ThemeMode.valueOf(preferences.getString(KEY_THEME_MODE, ThemeMode.SYSTEM.name).orEmpty())
    }.getOrDefault(ThemeMode.SYSTEM)

    fun saveThemeMode(mode: ThemeMode) {
        preferences.edit().putString(KEY_THEME_MODE, mode.name).apply()
    }

    companion object {
        const val PRESET_COUNT = 6
        val DEFAULT_PRESETS = listOf(15, 30, 45, 60, 120, 180)

        private const val PREFS_NAME = "dnd_timer_settings"
        private const val KEY_PRESETS = "quick_presets"
        private const val KEY_THEME_MODE = "theme_mode"
    }
}
