package com.dsynz.dndtimer.timer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class RestoreReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        TimerManager(context.applicationContext).reconcile()
    }
}
